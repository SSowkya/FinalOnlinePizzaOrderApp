package com.cg.pizzaorder.exception;

public class NoSuchPizzaException extends Exception {

	public NoSuchPizzaException(String str)
	{
		super(str);
	}
}
