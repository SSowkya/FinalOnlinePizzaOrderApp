package com.cg.pizzaorder.exception;

public class NoSuchPizzaOrderException extends Exception {

	public NoSuchPizzaOrderException(String str)
	{
		super(str);
	}
}
