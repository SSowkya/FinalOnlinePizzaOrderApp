package com.cg.pizzaorder.exception;

public class PizzaOrderAlreadyExists extends Exception {

	public PizzaOrderAlreadyExists(String str)
	{
		super(str);
	}
}
